风（Wind）人模与特写 modloader required

加载 Wind.mod.zip 即可正常使用，无需前置。
不兼容beauty-selector与其他任何开了外套槽的mod（Overfits，ReOverfits，susato-model等）
改脸请加 xxx Sideview for Wind，xxx为改脸名，效果见预览图（preview）
欢迎补充图片与二次创作。

Wind body and sideview modloader required

Load Wind.mod.zip and it will work fine, no need for a preloader.
Not compatible with beauty-selector and any other mods with over-outfits (Overfits, ReOverfits, susato-mods, etc).
Please add xxx Sideview for Wind, xxx is the name of the sideview, see the preview for the effect.
Welcome to add spirits and secondary creations.

注意事项
请注意，不得对内容进行再分发。
如果是从其他地方下载的，则表示未经同意。
谢谢。

Notice
Please be advised that redistribution of the content is not allowed. 
If this was downloaded from anywhere else, it means it is without consent. 
Thank you.

공지사항
콘텐츠의 재배포는 허용되지 않음을 알려드립니다. 
다른 곳에서 다운로드한 경우 동의 없이 다운로드한 것입니다. 
감사합니다.

Credits
作者 Author 작성자
挽风
贡献者 Contributors 기여자
Raven
YINER
Ree
稻谷
穆卿
黑玉
陆舟
dk
小企
头头
恶魔大祭司
miyako4828
寿里
叶斯
土豆
宵
m
米雪
\uFE0Flur
枝垂桜
圈圈
葬莜
StarDrop
盐酸
❤lur
西园
猫猫教传教士
Mamon

