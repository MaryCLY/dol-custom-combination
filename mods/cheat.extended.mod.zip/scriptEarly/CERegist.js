simpleFrameworks.addto('iModCheats', 'cheat_extended')
simpleFrameworks.addto('ModMenuBig', 'bccmeditor_button')
simpleFrameworks.addto('ModCaptionAfterDescription', 'bccmeditor_init')
simpleFrameworks.addto('ModCaptionAfterDescription', 'CEstatebox')
simpleFrameworks.addto('iModOptions', 'swich_DEBUG_MODE')

