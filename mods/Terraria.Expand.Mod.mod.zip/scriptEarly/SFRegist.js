simpleFrameworks.addto('ModMenuBig', 'void_bag');
simpleFrameworks.addto('ModMenuSmall', 'terra_expand_equipment');
simpleFrameworks.addto('ModMenuSmall', 'terra_expand_tool');

simpleFrameworks.addto('iModOptions', 'terraOptions');

simpleFrameworks.addto('iModStatist', 'terraStatistics');

simpleFrameworks.addto('ModSkillsBox', 'fishingskill');

simpleFrameworks.addto('iModHeader', 'terra_header');
simpleFrameworks.addto('iModFooter', 'terra_temperature');
simpleFrameworks.addto('iModHeader', 'vanityAccessoryTransformation');