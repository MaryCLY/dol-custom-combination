simpleFrameworks.addto('ModMenuBig', 'void_bag');
simpleFrameworks.addto('ModMenuSmall', 'terra_expand_accessories');
simpleFrameworks.addto('ModMenuSmall', 'terra_expand_bestiary');
simpleFrameworks.addto('iModOptions', 'cuteAngler');
simpleFrameworks.addto('iModOptions', 'artificialFishingPond');
simpleFrameworks.addto('iModFooter', 'snakeCharmersFluteUse');

simpleFrameworks.addto('ModSkillsBox', 'fishingskill');

