setup.terraMaterial = {
	"White_Pearl": {
        name: "White_Pearl",
        cn_name: "白珍珠",
        type: "material",
        amount: V.White_Pearl || 0,
        icon: "material/White_Pearl.png",
    },
	"Black_Pearl": {
        name: "Black_Pearl",
        cn_name: "黑珍珠",
        type: "material",
        amount: V.Black_Pearl || 0,
        icon: "material/Black_Pearl.png",
    },
	"Pink_Pearl": {
        name: "Pink_Pearl",
        cn_name: "粉珍珠",
        type: "material",
        amount: V.Pink_Pearl || 0,
        icon: "material/Pink_Pearl.png",
    },
	"White_Pearl": {
        name: "White_Pearl",
        cn_name: "白珍珠",
        type: "material",
        amount: V.White_Pearl || 0,
        icon: "material/White_Pearl.png",
    },
	"Sea_Prism": {
        name: "Sea_Prism",
        cn_name: "海棱晶",
        type: "material",
        amount: V.Sea_Prism || 0,
        icon: "material/Sea_Prism.png",
    },
	"Iron_Bar": {
        name: "Iron_Bar",
        cn_name: "铁锭",
        type: "Iron_Bar",
        amount: V.Iron_Bar || 0,
        icon: "material/Iron_Bar.png",
    },
	"Sea_Remains": {
        name: "Sea_Remains",
        cn_name: "海洋残渣",
        type: "material",
        amount: V.Sea_Remains || 0,
        icon: "material/Sea_Remains.png",
    },
	"Demonic_Bone_Ash": {
        name: "Demonic_Bone_Ash",
        cn_name: "恶魔骨灰",
        type: "material",
        amount: V.Demonic_Bone_Ash || 0,
        icon: "material/Demonic_Bone_Ash.png",
    },
}

function getAllCrateList() {
	for (let crate in setup.terraCrate) {
        setup.terraCrate[crate].amount = V[crate] || 0;
    }
    let all_crate_list = Object.keys(setup.terraCrate);
	return all_crate_list;
}
window.getAllCrateList = getAllCrateList

function getCrateObtainedList() {
	for (let crate in setup.terraCrate) {
        setup.terraCrate[crate].amount = V[crate] || 0;
    }
    let crate_obtained = Object.keys(setup.terraCrate);
    return crate_obtained.filter(crate => {
        return setup.terraCrate[crate].amount > 0;
    });
}
window.getCrateObtainedList = getCrateObtainedList;