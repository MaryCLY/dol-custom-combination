setup.terraRecipe = {
	"Enchanted_Pearl": {
        name: "Enchanted_Pearl",
        cn_name: "附魔珍珠",
        type: "accessories",
        amount: V.Enchanted_Pearl,
        icon: "fishing/fishing_accessories/Enchanted_Pearl.png",
		required_material: ["White_Pearl","Sea_Prism","Sea_Remains"],
		craft: "<<Enchanted_Pearl_crafting>>"
    },
}

function getAllCrateList() {
	for (let crate in setup.terraCrate) {
        setup.terraCrate[crate].amount = V[crate] || 0;
    }
    let all_crate_list = Object.keys(setup.terraCrate);
	return all_crate_list;
}
window.getAllCrateList = getAllCrateList

function getCrateObtainedList() {
	for (let crate in setup.terraCrate) {
        setup.terraCrate[crate].amount = V[crate] || 0;
    }
    let crate_obtained = Object.keys(setup.terraCrate);
    return crate_obtained.filter(crate => {
        return setup.terraCrate[crate].amount > 0;
    });
}
window.getCrateObtainedList = getCrateObtainedList;