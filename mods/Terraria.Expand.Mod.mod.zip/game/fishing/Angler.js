NamedNPC.add(
    new NamedNPC(
        'Angler', 
        '"孤儿"', 
        '渔夫', 
        'human'
    )
    .Init('m', 'teen')
)